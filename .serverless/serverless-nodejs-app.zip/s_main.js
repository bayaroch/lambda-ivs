
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'sindustry',
  applicationName: 'serverless-nodejs-app',
  appUid: 'K6wgSvMfhNWN1MjtZP',
  orgUid: '1624a51e-a886-442d-96e0-b3d75a13a3dd',
  deploymentUid: 'f7e2f3a9-98e1-497f-a9ea-41335cbdd620',
  serviceName: 'serverless-nodejs-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-nodejs-app-dev-main', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}